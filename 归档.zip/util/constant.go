/**
 * @Author $
 * @Description //TODO $
 * @Date $ $
 * @Param $
 * @return $
 **/
package util

//定义常量

const (
	NORMAL   = 1 //正常
	ABNORMAL = 2 //异常
)
